window.YACIN_SITE = {
  "site": {
    "title": "Yacin Photo | عکاسی مدلینگ، فضای باز و تبلیغاتی",
    "description": "Yacin Photo | عکاسی حرفه‌ای مدلینگ، فضای باز، تبلیغاتی و برندینگ",
    "whatsapp": "989140407325",
    "instagram": "yacin_photo",
    "telegram": "yacin_photo",
    "email": "contact@yacinphoto.com"
  },
  "hero": {
    "image": "/assets/hero.jpg",
    "tag": "عکاسی مدلینگ | فضای باز | تبلیغاتی",
    "titleLine1": "خلق تصویر حرفه‌ای،",
    "titleLine2": "ثبت حس، لحظه و شخصیت",
    "text": "یاسین فوتو با تمرکز بر عکاسی مدلینگ، پرتره فضای باز و پروژه‌های تبلیغاتی، برای برند شما و مدل‌های حرفه‌ای تصاویری ماندگار و سطح بالا خلق می‌کند.",
    "primaryText": "مشاهده نمونه‌کارها",
    "primaryHref": "#portfolio",
    "secondaryText": "دنبال کردن در اینستاگرام",
    "secondaryHref": "https://instagram.com/yacin_photo"
  },
  "categories": [
    {
      "id": "cat1",
      "name": "مدلینگ",
      "icon": ""
    },
    {
      "id": "cat2",
      "name": "فضای باز",
      "icon": "☀"
    },
    {
      "id": "cat3",
      "name": "تبلیغاتی",
      "icon": "◈"
    }
  ],
  "works": [
    {
      "id": "w1",
      "title": "Vantage",
      "image": "https://picsum.photos/seed/yasin-fm-1/800/1000",
      "category": "cat1"
    },
    {
      "id": "w2",
      "title": "Mirror",
      "image": "https://picsum.photos/seed/yasin-fm-2/800/1000",
      "category": "cat1"
    },
    {
      "id": "w3",
      "title": "Cosmos",
      "image": "https://picsum.photos/seed/yasin-fm-3/800/1000",
      "category": "cat3"
    },
    {
      "id": "w4",
      "title": "Current",
      "image": "https://picsum.photos/seed/yasin-fm-4/800/1000",
      "category": "cat1"
    },
    {
      "id": "w5",
      "title": "Threshold",
      "image": "https://picsum.photos/seed/yasin-fm-5/800/1000",
      "category": "cat2"
    },
    {
      "id": "w6",
      "title": "Hollow",
      "image": "https://picsum.photos/seed/yasin-fm-6/800/1000",
      "category": "cat3"
    },
    {
      "id": "w7",
      "title": "Ascent",
      "image": "https://picsum.photos/seed/yasin-fm-7/800/1000",
      "category": "cat1"
    },
    {
      "id": "w8",
      "title": "Array",
      "image": "https://picsum.photos/seed/yasin-fm-8/800/1000",
      "category": "cat2"
    }
  ],
  "locations": [
    {
      "id": "l1",
      "title": "استودیو نور",
      "subtitle": "پرتره و مدلینگ با نورپردازی کنترل‌شده",
      "cover": "https://picsum.photos/seed/yacin-location-studio/900/1200",
      "works": [
        {
          "id": "lw1",
          "title": "پرتره استودیویی ۰۱",
          "image": "https://picsum.photos/seed/yacin-studio-01/800/1060"
        },
        {
          "id": "lw2",
          "title": "پرتره استودیویی ۰۲",
          "image": "https://picsum.photos/seed/yacin-studio-02/800/1060"
        },
        {
          "id": "lw3",
          "title": "مدلینگ با نور سخت",
          "image": "https://picsum.photos/seed/yacin-studio-03/800/1060"
        }
      ]
    },
    {
      "id": "l2",
      "title": "بام شهری",
      "subtitle": "عکاسی در ارتفاع با پس‌زمینه افق شهر",
      "cover": "https://picsum.photos/seed/yacin-location-rooftop/900/1200",
      "works": [
        {
          "id": "lw4",
          "title": "غروب روی بام",
          "image": "https://picsum.photos/seed/yacin-rooftop-01/800/1060"
        },
        {
          "id": "lw5",
          "title": "پرتره شهری",
          "image": "https://picsum.photos/seed/yacin-rooftop-02/800/1060"
        },
        {
          "id": "lw6",
          "title": "خطوط افق",
          "image": "https://picsum.photos/seed/yacin-rooftop-03/800/1060"
        }
      ]
    },
    {
      "id": "l3",
      "title": "جنگل و طبیعت",
      "subtitle": "فضای سبز، نور طبیعی و حس آرامش",
      "cover": "https://picsum.photos/seed/yacin-location-forest/900/1200",
      "works": [
        {
          "id": "lw7",
          "title": "مسیر جنگلی",
          "image": "https://picsum.photos/seed/yacin-forest-01/800/1060"
        },
        {
          "id": "lw8",
          "title": "نور از میان درختان",
          "image": "https://picsum.photos/seed/yacin-forest-02/800/1060"
        },
        {
          "id": "lw9",
          "title": "پرتره در طبیعت",
          "image": "https://picsum.photos/seed/yacin-forest-03/800/1060"
        }
      ]
    }
  ],
  "services": [
    {
      "icon": "✦",
      "title": "عکاسی مدلینگ",
      "text": "عکاسی مدلینگ با ترکیب‌بندی حرفه‌ای، نورپردازی طبیعی یا مصنوعی، مناسب برای پورتفولیو، آژانس‌های مدلینگ و شبکه‌های اجتماعی."
    },
    {
      "icon": "☀",
      "title": "عکاسی فضای باز",
      "text": "ثبت پرتره و مدلینگ در لوکیشن‌های طبیعی، شهری، ساحلی، جنگلی و صنعتی با استفاده از نور طبیعی و حس سینمایی."
    },
    {
      "icon": "◈",
      "title": "عکاسی تبلیغاتی",
      "text": "تولید تصویر برای کمپین‌های تبلیغاتی، برندینگ، محصول، فشن، کافه، رستوران و کسب‌وکارهای نیازمند محتوای بصری حرفه‌ای."
    }
  ],
  "about": {
    "image": "https://picsum.photos/seed/yacin-about/900/1150",
    "title": "ثبت لحظه‌ها با نگاه حرفه‌ای و هنری",
    "text1": "یاسین فوتو با تمرکز بر عکاسی مدلینگ، پرتره فضای باز و پروژه‌های تبلیغاتی، تلاش می‌کند نه فقط یک عکس، بلکه یک حس، شخصیت و داستان را ثبت کند.",
    "text2": "هدف ما ساخت تصاویری است که هم از نظر هنری قوی باشند و هم از نظر تبلیغاتی بتوانند برای برند، محصول یا مدل ارزش واقعی ایجاد کنند.",
    "stats": [
      {
        "value": "+120",
        "label": "پروژه موفق"
      },
      {
        "value": "+80",
        "label": "همکاری با مدل"
      },
      {
        "value": "+35",
        "label": "پروژه تبلیغاتی"
      }
    ]
  },
  "instagram": [
    {
      "image": "https://picsum.photos/seed/yacin-insta-1/600/600",
      "href": "https://instagram.com/yacin_photo"
    },
    {
      "image": "https://picsum.photos/seed/yacin-insta-2/600/600",
      "href": "https://instagram.com/yacin_photo"
    },
    {
      "image": "https://picsum.photos/seed/yacin-insta-3/600/600",
      "href": "https://instagram.com/yacin_photo"
    },
    {
      "image": "https://picsum.photos/seed/yacin-insta-4/600/600",
      "href": "https://instagram.com/yacin_photo"
    },
    {
      "image": "https://picsum.photos/seed/yacin-insta-5/600/600",
      "href": "https://instagram.com/yacin_photo"
    },
    {
      "image": "https://picsum.photos/seed/yacin-insta-6/600/600",
      "href": "https://instagram.com/yacin_photo"
    }
  ],
  "contact": {
    "title": "رزرو جلسه عکاسی",
    "subtitle": "برای همکاری، رزرو جلسه عکاسی یا مشاوره پروژه، فرم زیر را تکمیل کنید.",
    "info": [
      {
        "label": "اینستاگرام",
        "value": "@yacin_photo",
        "href": "https://instagram.com/yacin_photo"
      },
      {
        "label": "واتس‌اپ",
        "value": "۰۹۱۴ ۰۴۰ ۷۳۲۵",
        "href": "https://wa.me/989140407325"
      },
      {
        "label": "ایمیل",
        "value": "contact@yacinphoto.com",
        "href": "mailto:contact@yacinphoto.com"
      },
      {
        "label": "حوزه فعالیت",
        "value": "عکاسی مدلینگ، فضای باز، تبلیغاتی و برندینگ",
        "href": ""
      }
    ]
  }
};
